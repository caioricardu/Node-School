const pets = ['cat', 'dog', 'rat']
i=0
for (i=0; i<3; i++){
    pets[i] = pets[i] + 's'
}
console.log(pets)