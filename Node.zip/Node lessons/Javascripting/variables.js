var example =  'some string'
console.log(example) 