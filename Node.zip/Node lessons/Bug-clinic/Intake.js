console.log('i am okay')
console.error('i am so incredibly not okay')